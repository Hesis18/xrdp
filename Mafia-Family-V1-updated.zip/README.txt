Mafia Family V1
Run: npm start
Open: http://localhost:3008
Images are in assets/. Add background music as assets/music.mp3.
Coin pack buttons are demo-only and do not process real payments. User data and role assignment are browser-local demo behavior, not secure multiplayer/server persistence.
